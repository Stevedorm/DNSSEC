To run:
    - The executable is already compiled from Stu, so you can run make a, make ns, make dnskey, and make soa to generate and verify the signatures.
    - The keys can be generated from a simple make keys command. This is useful if you need to do a key rollover or a key gets corrupted. It pulls the key data from the /vm_files/private or /public directory. These should be replaced in the event of a key rollover.
    - Keys and the executable can be cleaned with make clean for the dnssec_sign executable and make clean-keys to remove the key files.
    More instruction and details can be seen in the comments of the Makefile.
    - The input hex files are stored in hex_in, with approriately named files for the different records.
    - The signatures are stored in the signatures directory, also with appropriate names
    - These keys and signatures are now equipped with a ten year TTL, so they shouldn't need to be changed or updated unless changes to the zones are made.
    - These signatures are only made for the child zone, jmu.lab, but the keys for the parent zone, lab, are contained here. For now, the signatures have to be manually copied over from a dig query, and the hex strings manually built from wireshark output.
